#include<stdio.h>
#include<stdlib.h>

#include"headers.h"
int main(int argc, char *argv[])
{
printf("Modele main.c\n");
return 0;
}