#ifndef _FCT_H_
#define _FTC_H_

typedef enum{
FAUX,
VRAI
}booleen;

#endif //_FCT_H_
